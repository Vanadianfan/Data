#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
constexpr int P = 998244363;

char ibuf[1 << 23], *p1, *p2;
inline char Getchar(){
    return p1 == p2 && (p2 = (p1 = ibuf) + fread(ibuf, 1, 1 << 23, stdin), p1 == p2) ? EOF : *p1++;
}
template <typename T> void read(T &w){
    w = 0; char c = 0;
    int f = 1;
    while (!isdigit(c)){
        if (c == '-') f = -f;
        c = Getchar();
    }
    while (isdigit(c)) w = w * 10 + c - '0', c = Getchar();
    w *= f;
}

struct Matrix {  // 簡易版 Matrix 結構體，Matrix 模板類請見同級文件夾下 QFibonacci 標程。
    int n;
    long long m[101][101];
    Matrix(int n){
        this->n = n;
        memset(m, 0, sizeof(m));
    }
    void debug(void){
        for (int i = 1; i <= n; ++i) cout << m[i][1] << endl;
        cout << endl;
    }
    Matrix operator * (const Matrix &b) const {
        Matrix d(n);
        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= n; ++j)
                for (int k = 1; k <= n; ++k)
                    d.m[i][j] = (d.m[i][j] + b.m[i][k] * m[k][j] % P) % P;
        return d;
    }
    Matrix operator *= (const Matrix &b){
        *this = *this * b;
        return *this;
    }
};

void pow(Matrix &s, Matrix a, unsigned long long b){
    while (b){
        if (b & 1) s *= a;
        a *= a, b >>= 1;
    }
}

int main(){
    unsigned long long n; int p;
    read(n); read(p);

    Matrix e(p), V(p);
    for (int i = p; i; --i) read(e.m[i][1]), e.m[i][1] %= P;
    V.m[1][1] = V.m[1][p] = 1;
    for (int i = 2; i <= p; ++i) V.m[i][i - 1] = 1;
    pow(e, V, n);

    cout << e.m[p][1] << endl;
    return 0;
}