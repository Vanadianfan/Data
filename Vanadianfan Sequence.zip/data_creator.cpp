#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;
char PATH_FILE[] = "/Users/vanadianfan/Desktop/Code/C++/data/#146 Vanadianfan Sequence/VSequence";
template <typename T>
inline T rand(T P){
    return 1ll * rand() * rand() % P;
}
int main(){
    srand((unsigned)time(0));
    for (int T = 1; T <= 20; T++){
        char TMP_PATH_FILE[77];
        strcpy(TMP_PATH_FILE, PATH_FILE);
        char NUM[18];
        sprintf(NUM, "%d", T);
        int k = 5 * T;
        unsigned long long n;
        if (T == 20) n = ~0ull - rand(1000ull);
        else if (T == 1) n = 0ull;
        else if (T == 2) n = rand(k) + 1;
        else {
            int l = 14 + 5 * T / 2;
            n = rand(1ull << (l - 1)) + (1ull << (l - 1));
        }
        freopen(strcat(strcat(TMP_PATH_FILE, NUM), ".in"), "w", stdout);
        cout << n << (char)32 << k << endl;
        for (int i = 1; i <= k; ++i){
            int l = 12 + T;
            long long x = rand(1ll << l);
            if (T > 5) cout << (rand(2) && x ? "-" : "");
            cout << x;
            if (i != k) cout << (char)32;
        }
        cout << endl;
        fclose(stdout);
    }
    return 0;
}