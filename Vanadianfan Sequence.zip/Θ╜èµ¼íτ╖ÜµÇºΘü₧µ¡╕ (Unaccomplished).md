### 齊次線性遞歸

已知數列第 $0\sim k$ 項為 $f(0),f(1)\cdots f(k-1)$，有形如 $\displaystyle f(n)=\sum_{i=1}^k{a_if(n-i)}$ 的齊次線形遞推式。

姑且，令 $A_0=\begin{bmatrix}f(k-1)\\f(k-2)\\\cdots\\f(0)\end{bmatrix}$，$A_n=\begin{bmatrix}f(n+k-1)\\f(n+k-2)\\\cdots\\f(n)\end{bmatrix}$；設 $A_i$ 與 $A_{i+1}$ 轉移矩陣為 $M$。

其特徵方程式為 $\displaystyle F(x)=x^k-\sum_{i=1}^k{a_ix^{k-i}}$。

根據著名的~~我也不會的~~ $\mathrm{Cayley-Hamiton}$ 定理，有 $F(M)=0$。

令 $x^n\equiv G(x)\pmod {F(x)}$，

$\displaystyle\therefore A_n=A_0G(M)=A_0\sum_{i=0}^{k-1}{g_iM^i}$，其中 $g_i$ 為 $x^n\bmod F(x)$ 第 $i$ 項的係數。

但我們只關注矩陣 $A$ 的第 $1$ 個元素（從下往上），把 $A_0$ 合入 $\large\sum$ 運算符的項之後我們發現，

$A_0M^i$ 的第 $1$ 個元素即 $f(i)$，所以有 $\displaystyle f(n)=\sum_{i=0}^{k-1}{g_if(i)}$。