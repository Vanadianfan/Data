#include <ctime>
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
#define PATH "/Users/vanadianfan/Desktop/Code/C++/data/#146 Vanadianfan Sequence/VSequence"
constexpr int P = 998244363;

char ibuf[1 << 23], *p1, *p2;
inline char Getchar(){return p1 == p2 && (p2 = (p1 = ibuf) + fread(ibuf, 1, 1 << 23, stdin), p1 == p2) ? EOF : *p1++;}
template <typename T> void read(T &w){
    w = 0; char c = 0;
    int f = 1;
    while (!isdigit(c)){
        if (c == '-') f = -f;
        c = Getchar();
    }
    while (isdigit(c)) w = w * 10 + c - '0', c = Getchar();
    w *= f;
}

struct Matrix {
    int n;
    long long m[123][123];
    Matrix(int n){
        this->n = n;
        memset(m, 0, sizeof(m));
    }
    void debug(void){
        for (int i = 1; i <= n; ++i) cout << m[i][1] << endl;
        cout << endl;
    }
    Matrix operator * (const Matrix &b) const {
        Matrix d(n);
        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= n; ++j)
                for (int k = 1; k <= n; ++k)
                    d.m[i][j] = (d.m[i][j] + b.m[i][k] * m[k][j] % P) % P;
        return d;
    }
    Matrix operator *= (const Matrix &b){
        *this = *this * b;
        return *this;
    }
};

void pow(Matrix &s, Matrix a, unsigned long long b){
    while (b){
        if (b & 1) s *= a;
        a *= a, b >>= 1;
    }
}

int main(){
    for (int T = 1; T <= 20; T++){
        char NUM[18];
        sprintf(NUM, "%d", T);
        char TMP_PATH_IN[77], TMP_PATH_OUT[77];
        strcpy(TMP_PATH_IN, PATH);
        strcpy(TMP_PATH_OUT, PATH);
        clock_t s = clock();
        freopen(strcat(strcat(TMP_PATH_IN, NUM), ".in"), "r", stdin);
        sprintf(NUM, "%d", T);
        freopen(strcat(strcat(TMP_PATH_OUT, NUM), ".ans"), "w", stdout);
        unsigned long long n; int p;
        read(n); read(p);

        Matrix e(p), V(p);
        for (int i = p; i; --i) read(e.m[i][1]), e.m[i][1] %= P;
        V.m[1][1] = V.m[1][p] = 1;
        for (int i = 2; i <= p; ++i) V.m[i][i - 1] = 1;
        pow(e, V, n);

        cout << e.m[p][1] << endl;
        fclose(stdin);
        fclose(stdout);
        cerr << "Round " << T << ": " << clock() - s << "µs" << endl;
    }
    return 0;
}