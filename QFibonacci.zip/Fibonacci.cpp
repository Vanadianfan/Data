#include <cstring>
#include <iostream>
#define MOD 998244353
using namespace std;

template<typename type>
class Matrix {  // 使用模板類實現矩陣對象的操作
 private:
    size_t n;
    type mt[3][3];  // 按實際需要更改數組範圍

 public:
    Matrix(size_t n) : n(n) { memset(mt, 0, sizeof(mt)); }
    Matrix(Matrix &p) : n(p.n) {  // 構造和目標矩陣大小相同的元矩陣
        memset(mt, 0, sizeof(mt));
        for (int i = 1; i <= n; i++) mt[i][i] = 1;
    }

    friend void reset(Matrix &);

    Matrix operator * (const Matrix &b) const {
        Matrix<type> d(n);
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                for (int k = 1; k <= n; k++)
                    (d.mt[i][j] += mt[i][k] * b.mt[k][j] % MOD) %= MOD;
        return d;
    }
    Matrix operator *= (const Matrix &b) {
        *this = *this * b;
        return *this;
    }

    void power(long long b){
        Matrix<type> s(*this);
        while (b){
            if (b & 1) s = s * *this;
            *this *= *this, b >>= 1;
        }
        *this = s;
    }

    type answer(void){ return mt[n][1]; }
};

void reset(Matrix<long long> &a){  // 按實際需要修改此函數
    a.mt[1][1] = a.mt[1][2] = a.mt[2][1] = 1;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long x; cin >> x;
    if (!x){ cout << 0 << endl; return 0; }

    Matrix<long long> a(2), *p = &a;  // 按實際需要傳入構造函數的數值
    reset(a);
    p->power(x);
    cout << p->answer() << endl;
    return 0;
}